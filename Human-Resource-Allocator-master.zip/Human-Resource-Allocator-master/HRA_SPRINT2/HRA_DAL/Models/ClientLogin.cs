﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class ClientLogin
    {
        public ClientLogin()
        {
            ClientProjectDetailsClient = new HashSet<ClientProjectDetails>();
            ClientProjectDetailsEmail = new HashSet<ClientProjectDetails>();
        }

        public string ClientId { get; set; }
        public string ClientName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }

        public ICollection<ClientProjectDetails> ClientProjectDetailsClient { get; set; }
        public ICollection<ClientProjectDetails> ClientProjectDetailsEmail { get; set; }
    }
}
