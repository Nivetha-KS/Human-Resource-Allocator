﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class EmployeeLogin
    {
        public EmployeeLogin()
        {
            Employee = new HashSet<Employee>();
        }

        public string EmailId { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }

        public ICollection<Employee> Employee { get; set; }
    }
}
