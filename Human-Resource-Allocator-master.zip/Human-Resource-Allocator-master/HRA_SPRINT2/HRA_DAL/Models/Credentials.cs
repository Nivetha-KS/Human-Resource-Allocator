﻿using System;
using System.Collections.Generic;

namespace HRA_DAL.Models
{
    public partial class Credentials
    {
        public string EmailId { get; set; }
        public string Experience { get; set; }
        public string Domain { get; set; }
        public string Certification { get; set; }
        public int Rating { get; set; }
    }
}
