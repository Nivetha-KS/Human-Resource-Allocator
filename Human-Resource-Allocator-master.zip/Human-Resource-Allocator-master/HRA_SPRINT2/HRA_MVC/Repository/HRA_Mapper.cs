﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using HRA_DAL.Models;

namespace HRA_MVC.Repository
{
    public class HRA_Mapper : Profile
    {
        public HRA_Mapper()
        {
            CreateMap<Employee, Models.Employee>();
            CreateMap<Models.Employee, Employee>();
            CreateMap<ClientProjectDetails, Models.ClientProjectDetails>();
            CreateMap<Models.ClientProjectDetails, ClientProjectDetails>();
            CreateMap<Credentials, Models.Credentials>();
            CreateMap<Models.Credentials, Credentials>();
            CreateMap<CreditPoints, Models.CreditPoints>();
            CreateMap<Models.CreditPoints, CreditPoints>();
            CreateMap<DeveloperProjectDetails, Models.DeveloperProjectDetails>();
            CreateMap<Models.DeveloperProjectDetails, DeveloperProjectDetails>();
        }
    }
}
