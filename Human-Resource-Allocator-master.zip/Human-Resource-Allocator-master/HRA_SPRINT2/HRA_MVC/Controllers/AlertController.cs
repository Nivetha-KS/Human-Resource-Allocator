﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace HRA_MVC.Controllers
{
    public class AlertController : Controller
    {
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult Logins()
        {
            return View();
        }
        public IActionResult Success()
        {
            return View();
        }
        public IActionResult ErrorPage()
        {
            return View();
        }
        public IActionResult Done()
        {
            return View();
        }
        public IActionResult InProgress()
        {
            return View();
        }
        public IActionResult Completed()
        {
            return View();
        }
    }
}