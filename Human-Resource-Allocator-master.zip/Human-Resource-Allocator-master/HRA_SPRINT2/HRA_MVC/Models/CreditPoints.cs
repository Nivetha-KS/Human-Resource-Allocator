﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HRA_MVC.Models
{
    public class CreditPoints
    {
        public string EmailId { get; set; }
        public string Domain { get; set; }
        public int Credits { get; set; }
    }
}
