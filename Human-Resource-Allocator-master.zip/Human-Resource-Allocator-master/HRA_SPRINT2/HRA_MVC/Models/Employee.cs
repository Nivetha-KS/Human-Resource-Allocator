﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HRA_MVC.Models
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        [Required(ErrorMessage = "EmployeeName is mandatory.")]
        public string EmployeeName { get; set; }
        [Required(ErrorMessage = "Gender is mandatory.")]
        public string Gender { get; set; }
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address")]
        [Required(ErrorMessage = "EmailId is mandatory.")]
        [DisplayName("Email Id ")]
        public string EmailId { get; set; }
        [Required(ErrorMessage = "ContactNumber is mandatory.")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Give appropriate contact number")]
        public long ContactNumber { get; set; }
        [Required(ErrorMessage = "DOB is mandatory.")]
        [DataType(DataType.Date)]
        [MinimumAge(18,ErrorMessage="Minimum age should be 18")]        
        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Designation is mandatory.")]
        public string Designation { get; set; }
        [Required(ErrorMessage = "Domain is mandatory.")]
        public string Domain { get; set; }
        [Required(ErrorMessage = "Location is mandatory.")]
        public string Location { get; set; }
        public string Allocation { get; set; }
    }
}
