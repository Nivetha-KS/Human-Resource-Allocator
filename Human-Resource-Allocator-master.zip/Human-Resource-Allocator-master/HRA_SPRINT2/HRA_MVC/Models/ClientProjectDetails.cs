﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HRA_MVC.Models
{
    public class ClientProjectDetails
    {
        public string ProjectId { get; set; }
        public string ClientId { get; set; }
        [Required(ErrorMessage = "EmailId is mandatory.")]
        public string EmailId { get; set; }
        [Required(ErrorMessage = "ProjectName is mandatory.")]
        public string ProjectName { get; set; }
        [Required(ErrorMessage = "Stream is mandatory.")]
        public string Stream { get; set; }
        [Required(ErrorMessage = "StartDate is mandatory.")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [Required(ErrorMessage = "EndDate is mandatory.")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
        [Required(ErrorMessage = "NoOfEmployeesReq is mandatory.")]
        public int NoOfEmployeesReq { get; set; }

    }
}
