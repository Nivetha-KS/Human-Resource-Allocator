﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HRA_MVC.Models
{
    public class Credentials
    {
        public string EmailId { get; set; }
        [Required(ErrorMessage = "Experience is mandatory.")]
        public string Experience { get; set; }
        [Required(ErrorMessage = "Domain is mandatory.")]
        public string Domain { get; set; }
        [Required(ErrorMessage = "Certification is mandatory.")]
        public string Certification { get; set; }
        [Required(ErrorMessage = "Rating is mandatory.")]
        public int Rating { get; set; }
        
    }
}
